package com.example.administrator.cateringimp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class CatererStaffHomeScreen extends AppCompatActivity {

    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caterer_staff_home_screen);
        id = getIntent().getStringExtra("userid");
    }

    public void onclickUpdateProfile(View view) {
        Intent myIntent=new Intent(view.getContext(),UpdateProfile.class);
        startActivity(myIntent);
    }


    public void onclickLogout(View view) {

        Intent myIntent=new Intent(view.getContext(),Login.class);
        startActivity(myIntent);
        Toast.makeText(this, "Logout Successfully", Toast.LENGTH_SHORT).show();
    }

    public void onclickAssign(View view) {
        Intent myIntent=new Intent(view.getContext(),ViewAssignedEvents.class);
        //        .putExtra("userid", id)
          //      .putExtra("name","Kishore");
        startActivity(myIntent);
    }
}
