package com.example.administrator.cateringimp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

/**
 * Created by Administrator on 4/25/2018.
 */

public class ViewSelectedEventFromListUser extends AppCompatActivity {

    TextView tv1, tv2, tv3, tv4, tv5, tv6, tv7, tv8;

    public  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_selected_event_fromlist_user);

        String event_name = getIntent().getStringExtra("eventName");

        tv1 = findViewById(R.id.textView47);
       // tv2 = findViewById(R.id.textView48);
        tv3 = findViewById(R.id.textView59);
        tv4 = findViewById(R.id.textView64);
        tv5 = findViewById(R.id.textView63);
        tv6 = findViewById(R.id.textView62);
        tv7 = findViewById(R.id.textView61);
        tv8 = findViewById(R.id.textView60);


        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        Cursor res;
        res = databaseHelper.getAllData("addresourcesuser");
        //System.out.println(res.getCount());
        res.moveToFirst();
        do {
            if(res.getString(res.getColumnIndex(DatabaseHelper.COL_15)) != null) {
                //System.out.println(res.getString(res.getColumnIndex(DatabaseHelper.COL_15)));
                //System.out.println(".................................." + event_name);

                if (res.getString(res.getColumnIndex(DatabaseHelper.COL_15)).equalsIgnoreCase(event_name)) {
                    tv1.setText(event_name);
                   // tv2.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_22)));
                    tv3.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_26)));
                    tv4.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_18)));
                    tv5.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_17)));
                    tv6.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_25)));
                    tv7.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_24)));
                    tv8.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_16)));
                    break;
                }
            }
        }while (res.moveToNext());
    }

    public void onclickSubmit(View view) {
        Intent myIntent=new Intent(view.getContext(),UserHomeScreen.class);
        startActivity(myIntent);

    }

}
