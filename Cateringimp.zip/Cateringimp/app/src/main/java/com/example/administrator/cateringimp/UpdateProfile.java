package com.example.administrator.cateringimp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class UpdateProfile extends AppCompatActivity {
    SQLiteOpenHelper openHelper;
    SQLiteDatabase sqLiteDatabase;
    Button _btnupdate;
    EditText _txtname, _txtsurname, _txtid, _txtpassword, _txtdateofbirth, _txtcity, _txtstate, _txtcountry, _txtzipcode, _txtemail, _txtphone, _txtaddress;
    RadioGroup _txtgender,_txtrole;
    RadioButton _txtroleradio,_txtgenderradio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_profile);
        openHelper = new DatabaseHelper(this);
        _btnupdate = (Button) findViewById(R.id.btnupdate);
        _txtname = (EditText) findViewById(R.id.txtname);
        _txtid = (EditText) findViewById(R.id.txtid);
        _txtpassword = (EditText) findViewById(R.id.txtpassword);
        _txtdateofbirth = (EditText) findViewById(R.id.txtdateofbirth);
        _txtcity = (EditText) findViewById(R.id.txtcity);
        _txtstate = (EditText) findViewById(R.id.txtstate);
        _txtcountry = (EditText) findViewById(R.id.txtcountry);
        _txtzipcode = (EditText) findViewById(R.id.txtzipcode);
        _txtaddress = (EditText) findViewById(R.id.txtaddress);
        _txtemail = (EditText) findViewById(R.id.txtemailid);
        _txtphone = (EditText) findViewById(R.id.txtphoneno);
        _txtsurname = (EditText) findViewById(R.id.txtsurname);

        //_txtgender = (RadioGroup) findViewById(R.id.radioSex);
        _txtrole = (RadioGroup) findViewById(R.id.radioUsertype);
    }
    public void onclickUpdate(View view) {
        Intent myIntent=new Intent(view.getContext(),UserHomeScreen.class);
        sqLiteDatabase = openHelper.getWritableDatabase();
        String id = _txtid.getText().toString();
        String name = _txtname.getText().toString();
        String surname = _txtsurname.getText().toString();
        String password = _txtpassword.getText().toString();
        String dateofbirth = _txtdateofbirth.getText().toString();
        String city = _txtcity.getText().toString();
        String state = _txtstate.getText().toString();
        String country = _txtcountry.getText().toString();
        String zipcode = _txtzipcode.getText().toString();
        String address = _txtaddress.getText().toString();
        String email = _txtemail.getText().toString();
        String phone = _txtphone.getText().toString();
        //int genderid;
        //genderid = _txtgender.getCheckedRadioButtonId();
        //_txtgenderradio = findViewById(genderid);
        //String gender = _txtgenderradio.getText().toString();
        String gender = "female";
        int roleid = _txtrole.getCheckedRadioButtonId();
        _txtroleradio = findViewById(roleid);
        String role = _txtroleradio.getText().toString();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COL_1, id);
        contentValues.put(DatabaseHelper.COL_2, password);
        contentValues.put(DatabaseHelper.COL_3, name);
        contentValues.put(DatabaseHelper.COL_4, surname);
        contentValues.put(DatabaseHelper.COL_5, dateofbirth);
        contentValues.put(DatabaseHelper.COL_6, address);
        contentValues.put(DatabaseHelper.COL_7, city);
        contentValues.put(DatabaseHelper.COL_8, state);
        contentValues.put(DatabaseHelper.COL_9, country);
        contentValues.put(DatabaseHelper.COL_10, zipcode);
        contentValues.put(DatabaseHelper.COL_11, email);
        contentValues.put(DatabaseHelper.COL_12,gender);
        contentValues.put(DatabaseHelper.COL_13,role);
        contentValues.put(DatabaseHelper.COL_14, phone);
        long id1 = sqLiteDatabase.update(DatabaseHelper.TABLE_NAME,contentValues, "UTAID= ?", new String[]{id});



        Toast.makeText(this, "Profile Updated Sucessfully", Toast.LENGTH_SHORT).show();
        startActivity(myIntent);
    }
}
