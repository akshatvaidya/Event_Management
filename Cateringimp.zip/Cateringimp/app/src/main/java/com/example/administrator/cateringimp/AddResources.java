package com.example.administrator.cateringimp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

public class AddResources extends AppCompatActivity {
    SQLiteOpenHelper openHelper;
    SQLiteDatabase sqLiteDatabase;
    RadioGroup _txtGMealType,_txtGEntertainment,_txtGMealformality,_txtGCuisine,_txtGHall,_txtGDrinkVenue;
    RadioButton _txtmealtyperadio,_txtentertainmentradio,_txtformalityradio,_txtcuisineradio,_txthallradio,_txtdrinkvenueradio;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_resources);
        openHelper = new DatabaseHelper(this);
        sqLiteDatabase= openHelper.getWritableDatabase();
        _txtGEntertainment = (RadioGroup) findViewById(R.id.radioEntertainment);
        _txtGHall = (RadioGroup) findViewById(R.id.radioHall);
        _txtGMealformality =(RadioGroup) findViewById(R.id.radioMealFormality);
        _txtGCuisine= (RadioGroup) findViewById(R.id.radioCuisine);
        _txtGHall= (RadioGroup) findViewById(R.id.radioHall);
        _txtGCuisine= (RadioGroup) findViewById(R.id.radioCuisine);
        _txtGMealType=(RadioGroup) findViewById(R.id.radioMealtype);
        _txtGDrinkVenue = (RadioGroup) findViewById(R.id.radioDrink);


    }



    public void onclickSubmit(View view) {

        int entertainmentid = _txtGEntertainment.getCheckedRadioButtonId();
        _txtentertainmentradio= findViewById(entertainmentid);
        String entertainment = _txtentertainmentradio.getText().toString();
        int hallid = _txtGHall.getCheckedRadioButtonId();
        _txthallradio= findViewById(hallid);
        String hall = _txtentertainmentradio.getText().toString();

        int cuisineid = _txtGCuisine.getCheckedRadioButtonId();
        _txtcuisineradio= findViewById(cuisineid);
        String cuisine = _txtcuisineradio.getText().toString();

        int mealformalityid = _txtGMealformality.getCheckedRadioButtonId();
        _txtformalityradio= findViewById(mealformalityid);
        String mealformality = _txtformalityradio.getText().toString();

        int drinkid = _txtGDrinkVenue.getCheckedRadioButtonId();
        _txtdrinkvenueradio= findViewById(drinkid);
        String drink = _txtdrinkvenueradio.getText().toString();

        int mealTypeid = _txtGMealType.getCheckedRadioButtonId();
        _txtmealtyperadio= findViewById(mealTypeid);
        String mealtype = _txtmealtyperadio.getText().toString();

        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COL_16, entertainment);
        contentValues.put(DatabaseHelper.COL_17, mealtype);
        contentValues.put(DatabaseHelper.COL_18,cuisine);
        contentValues.put(DatabaseHelper.COL_24, mealformality);
        contentValues.put(DatabaseHelper.COL_25, drink);
        contentValues.put(DatabaseHelper.COL_26, hall);
        contentValues.put(DatabaseHelper.COL_27, 0);
        Intent myIntent=new Intent(view.getContext(),CatererHomeScreen.class);
        String event_name = getIntent().getStringExtra("extra");
        contentValues.put(DatabaseHelper.COL_15, event_name);
        long id1 = sqLiteDatabase.insert("addresources", null, contentValues);

        startActivity(myIntent);
        Toast.makeText(this, "Resources added. Event Created Sucessfull", Toast.LENGTH_SHORT).show();
    }

}
