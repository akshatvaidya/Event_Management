package com.example.administrator.cateringimp;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;


public class SearchEvent extends AppCompatActivity {

    EditText et1;
    ArrayList<String> list;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_event);


    }

    public void onClickSearchEvent(View view) {
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        final Cursor res;
        res = databaseHelper.getAllData("createnewevents");
        et1 = findViewById(R.id.editText8);
        System.out.println(res.getCount());
        System.out.println(et1.getText().toString());
//        System.out.println(res.getString(res.getColumnIndex(DatabaseHelper.COL_22)));

        list = new ArrayList<String>();
        res.moveToFirst();
        int i = 0;

        do {
            //System.out.println(".............................." + res.getColumnIndex(DatabaseHelper.COL_224) + et1 );
            if (res.getString(res.getColumnIndex(DatabaseHelper.COL_22)).equalsIgnoreCase(et1.getText().toString())) {
                System.out.println(".........................");
                list.add(res.getString(res.getColumnIndex(DatabaseHelper.COL_22)) + "\t" +
                        res.getString(res.getColumnIndex(DatabaseHelper.COL_15)));
                i++;
            }
        } while (res.moveToNext());

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        ListView listView = findViewById(R.id.eventList);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long id) {
                startActivity(new Intent(SearchEvent.this, ViewSelectedEventFromListCaterer.class)
                        .putExtra("eventName", list.get(i).split("\t")[1]));
            }
        });
    }
}
