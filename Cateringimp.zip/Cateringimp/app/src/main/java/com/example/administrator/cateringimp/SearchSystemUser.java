package com.example.administrator.cateringimp;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class SearchSystemUser extends AppCompatActivity {
    private TextView tv1;
    EditText fn, ln;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_system_user);

        fn = findViewById(R.id.editText21);
        ln = findViewById(R.id.editText22);
    }

    public void onclickSearch(View view) {

        Intent myIntent = new Intent(view.getContext(), SearchFound.class)
                .putExtra("fn", fn.getText().toString())
                .putExtra("ln", ln.getText().toString());
        startActivity(myIntent);
        Toast.makeText(this, "Search Found", Toast.LENGTH_SHORT).show();
    }
}

