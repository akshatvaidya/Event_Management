package com.example.administrator.cateringimp;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class SearchFound extends AppCompatActivity {

    String fn, ln;

    TextView tv2;
    boolean searchFound = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_found);

        fn = getIntent().getStringExtra("fn");
        ln = getIntent().getStringExtra("ln");
        tv2 = findViewById(R.id.tv2);

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        Cursor res;
        res = databaseHelper.getAllData("register");
        System.out.println(res.getCount());
        res.moveToFirst();
        do {
            if (res.getString(2).equalsIgnoreCase(fn) &&
                    res.getString(3).equalsIgnoreCase(ln)) {
                tv2.setText(fn + " " + ln);
                searchFound = true;
                break;
            }
        }
        while (res.moveToNext());

        tv2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (searchFound) {
                    onclickSearch(view);
                }
            }
        });

    }

    public void onclickSearch(View view) {
        Intent myIntent = new Intent(view.getContext(), ViewSystemUserDetails.class)
                .putExtra("name",fn )
                .putExtra("surname", ln);
        startActivity(myIntent);

    }

}
