package com.example.administrator.cateringimp;

import android.content.Intent;
import android.database.Cursor;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;

public class CalenderActivity extends AppCompatActivity {

    public int year,month,date;
    TextView tv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_calender_user);

        tv = findViewById(R.id.tv);

        CalendarView calendarView = findViewById(R.id.calendarView);
        calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int y, int m, int d) {
                m += 1;
//                System.out.println(d);
//                System.out.println(m);
//                System.out.println(y);
                    date = d;
                    month =m;
                    year =y;
                ((Button) findViewById(R.id.button42)).setText(m + "/" + d + "/" + y);
            }
        });

    }

    public void onClickButton(View view) {

      /*  DatabaseHelper databaseHelper = new DatabaseHelper(this);
        Cursor res;
        res = databaseHelper.getAllData("createnewevents");
        System.out.println(res.getCount());
        res.moveToFirst();

        do {
            if (res.getString(res.getColumnIndex(DatabaseHelper.COL_224)).equalsIgnoreCase(month+"/"+date+"/"+year)) {
                tv.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_15)) +
                        "     " + res.getString(res.getColumnIndex(DatabaseHelper.COL_21)));
            }
        }
        while (res.moveToNext());
    } */



        Intent myIntent=new Intent(view.getContext(),ViewSelectedEventFromCalenderCaterer.class);
        startActivity(myIntent);

    }
}
