package com.example.administrator.cateringimp;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class ReviewRegisterationRequestList extends AppCompatActivity {


    ArrayList<String> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_registeration_request_list);

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        Cursor res;
        res = databaseHelper.getAllData("registrationRequests");
        System.out.println(res.getCount());
        res.moveToFirst();
        list = new ArrayList<String>();
//        for (int i = 0; i < res.getCount(); i++) {
//            list.add(i, res.getString(0) + "\t" + res.getString(1));
//        }
        int i = 0;
        do {
            list.add(i, res.getString(0) + "\t" + res.getString(1));
            i++;
        }while (res.moveToNext());

        ArrayAdapter<String> itemsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(itemsAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                startActivity(new Intent(ReviewRegisterationRequestList.this, ReviewRequest.class)
                        .putExtra("name", list.get(position).split("\t")[1])
                        .putExtra("uid", list.get(position).split("\t")[0])

                );
            }
        });
    }


    public void onclickReview(View view) {
        Intent myIntent = new Intent(view.getContext(), ReviewRequest.class);
        startActivity(myIntent);
    }
}
