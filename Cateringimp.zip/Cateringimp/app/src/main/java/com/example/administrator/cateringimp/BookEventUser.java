package com.example.administrator.cateringimp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Created by Administrator on 4/25/2018.
 */

public class BookEventUser extends AppCompatActivity
{


    EditText _txteventname,_txtoccassiontype,_date;
    Button _btnassignstaff;
    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {


        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_event_user);


        openHelper = new DatabaseHelper(this);
        db = openHelper.getWritableDatabase();
        _txteventname=(EditText)findViewById(R.id.txteventname);
        _txtoccassiontype=(EditText)findViewById(R.id.txtoccassiontype);
        _date=(EditText)findViewById(R.id.date);
        _btnassignstaff=(Button)findViewById(R.id.submit);


    }



    public void onclicksubmit(View view) {
        String event_name = _txteventname.getText().toString();
        String occassion_type=_txtoccassiontype.getText().toString();
        String date=_date.getText().toString();
        // Log.e("cateringimp","The event name is" + event_name);
        ContentValues contentValues = new ContentValues();
        //ContentValues contentValues1 = new ContentValues();
        //ContentValues contentValues2 = new ContentValues();
        //String value = "eventname";
        contentValues.put(DatabaseHelper.COL_15,event_name);
        contentValues.put(DatabaseHelper.COL_22,date);
        contentValues.put(DatabaseHelper.COL_21,occassion_type);

        Intent myIntent=new Intent(view.getContext(),AddResourcesUser.class);
        String id = getIntent().getStringExtra("userid");
        contentValues.put(DatabaseHelper.COL_1,id);
        long id1 = db.insert("bookevent", null,contentValues);
        Toast.makeText(this, "Booking an event", Toast.LENGTH_SHORT).show();
        myIntent.putExtra("extra", event_name);
        startActivity(myIntent);
    }
}

