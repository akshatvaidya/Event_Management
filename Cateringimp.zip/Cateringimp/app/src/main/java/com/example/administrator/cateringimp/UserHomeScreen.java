package com.example.administrator.cateringimp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class UserHomeScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_home_screen);
    }

   public void viewMyEvents(View view) {
       String id = getIntent().getStringExtra("userid");
     Intent myIntent=new Intent(view.getContext(),ViewMyEvents.class)
             .putExtra("userid", id);
       startActivity(myIntent);
    }

    public void onclickbookevent(View view) {
        Intent myIntent=new Intent(view.getContext(),BookEventUser.class);
        String id = getIntent().getStringExtra("userid");
        myIntent.putExtra("userid",id);
        startActivity(myIntent);
    }

    /*public void onclickbookevent(View view) {
        Intent myIntent=new Intent(view.getContext(),BookEventUser.class);
     ////   String id = getIntent().getStringExtra("extra");
        myIntent.putExtra("extra",id);
        startActivity(myIntent);
        //Intent myIntent1=new Intent(view.getContext(),CreateNewEvent.class);
        //startActivity(myIntent1);
    }*/
    public void onclickupdate(View view) {
        Intent myIntent=new Intent(view.getContext(),UpdateProfile.class);
        startActivity(myIntent);
    }
    public void onclickLogout(View view) {
        Intent myIntent=new Intent(view.getContext(),Login.class);
        startActivity(myIntent);
    }
}
