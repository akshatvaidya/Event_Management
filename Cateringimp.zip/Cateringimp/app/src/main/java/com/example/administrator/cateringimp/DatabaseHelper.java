package com.example.administrator.cateringimp;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by Administrator on 4/17/2018.
 */

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "regy.db";


    public static final String TABLE_NAME = "register";
    public static final String COL_1 = "UTAID";
    public static final String COL_2 = "Password";
    public static final String COL_3 = "Name";
    public static final String COL_4 = "Surname";
    public static final String COL_5 = "Dateofbirth";
    public static final String COL_6 = "Address";
    public static final String COL_7 = "City";
    public static final String COL_8 = "State";
    public static final String COL_9 = "Country";
    public static final String COL_10 = "Zipcode";
    public static final String COL_11 = "Emailid";
    public static final String COL_12 = "Gender";
    public static final String COL_13 = "Role";
    public static final String COL_14 = "Phone";


    public static final String COL_15 = "eventname";
    public static final String COL_16 = "entertainmentitems";
    public static final String COL_17 = "foodmealtype";
    public static final String COL_18 = "cuisine";
    //public static final String COL_19="Role";
    //  public static final String  COL_20="Phone";

    public static final String COL_21 = "occassiontype";
    public static final String COL_22 = "Date";
    public static final String COL_224 = "date";

    public static final String COL_23 = "size";
    public static final String COL_24 = "mealformality";
    public static final String COL_25 = "drinkvenue";
    public static final String COL_26 = "hall";
    public static final String COL_27 = "size";
    public static final String COL_28 = "name";

    public static final String TABLE_REGISTER_REQUEST = "registrationRequests";
    public static final String COL_29 = "UTAID";
    public static final String COL_30 = "name";


    private SQLiteDatabase db;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
        db = this.getWritableDatabase();
    }


    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + "createnewevents");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + "assignstaffmembers");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + "addresources");
        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_NAME + " (UTAID TEXT PRIMARY KEY,Password TEXT,Name TEXT,Surname TEXT,Dateofbirth TEXT,Address TEXT,City TEXT,State TEXT,Country TEXT,ZipCode TEXT,Emailid TEXT,Gender TEXT,Role TEXT,Phone TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE " + "createnewevents" + " (eventname TEXT PRIMARY KEY,Date String,occassiontype TEXT)");
//        System.out.println("create new event table will be created");
//        Log.d("Cateringimp", "assign staff members is gonna get created");

        sqLiteDatabase.execSQL("CREATE TABLE " + TABLE_REGISTER_REQUEST + " (UTAID TEXT PRIMARY KEY, Date String, occasiontype TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE " + "assignstaffmembers" + " (name TEXT PRIMARY KEY,eventname TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE " + "addresources" + " (eventname TEXT PRIMARY KEY,entertainmentitems TEXT,foodmealtype TEXT,cuisine TEXT,mealformality TEXT,drinkvenue TEXT,hall TEXT,size TEXT )");
        sqLiteDatabase.execSQL("CREATE TABLE " + "bookevent" + " (eventname TEXT PRIMARY KEY,UTAID TEXT,Date String,occassiontype TEXT)");
        sqLiteDatabase.execSQL("CREATE TABLE " + "addresourcesuser" + " (eventname TEXT PRIMARY KEY,entertainmentitems TEXT,foodmealtype TEXT,cuisine TEXT,mealformality TEXT,drinkvenue TEXT,hall TEXT,size TEXT )");

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

        onCreate(sqLiteDatabase);
    }

    public Cursor getAllData(String tablename) {
        Cursor res = db.rawQuery("Select * FROM " + tablename, null);
        return res;
    }
}
