package com.example.administrator.cateringimp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {
    SQLiteDatabase db;
    SQLiteOpenHelper openHelper;
    Cursor cursor;
    Button _btnLogin;
    EditText _txtid, _txtpassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        openHelper = new DatabaseHelper(this);
        db = openHelper.getReadableDatabase();
        _txtid = (EditText) findViewById(R.id.txtid);
        _txtpassword = (EditText) findViewById(R.id.txtpassword);
        _btnLogin = (Button) findViewById(R.id.btnlogin);

    }

    public void onclicklogin(View view) {
;
        String id = _txtid.getText().toString();
        String pass = _txtpassword.getText().toString();
        cursor = db.rawQuery(String.format(" SELECT * FROM %s WHERE %s =? AND %s =? ",
                DatabaseHelper.TABLE_NAME, DatabaseHelper.COL_1, DatabaseHelper.COL_2), new String[]{id, pass});
        cursor.moveToFirst();
       // System.out.println(cursor.getString(12));


        if (cursor != null && cursor.getCount() > 0) {



            if(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_13)).equalsIgnoreCase("User")) {
                Intent myIntent1 = new Intent(Login.this, UserHomeScreen.class);
                myIntent1.putExtra("userid", id);
                startActivity(myIntent1);
                Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_SHORT).show();
            }
            else if(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_13)).equalsIgnoreCase("Caterer")) {
                Intent myIntent1 = new Intent(Login.this, CatererHomeScreen.class);
                myIntent1.putExtra("userid", id);
                startActivity(myIntent1);
                Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_SHORT).show();
            }
            else if(cursor.getString(cursor.getColumnIndex(DatabaseHelper.COL_13)).equalsIgnoreCase("Admin")) {
                Intent myIntent1 = new Intent(Login.this, AdminHomeScreen.class);
                myIntent1.putExtra("userid", id);
                startActivity(myIntent1);
                Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_SHORT).show();
            }
            else {
                Intent myIntent1 = new Intent(Login.this, CatererStaffHomeScreen.class);
                myIntent1.putExtra("userid", id);
                startActivity(myIntent1);
                Toast.makeText(getApplicationContext(), "Login Success", Toast.LENGTH_SHORT).show();
            }
            }


            else {
                Toast.makeText(getApplicationContext(), "Login error", Toast.LENGTH_SHORT).show();
                Log.e("cateringimp", "the user is ");
            }
        }












    public void onclickForgot(View view) {
        Intent myIntent=new Intent(view.getContext(),ForgotPassword.class);
        startActivity(myIntent);
    }

    public void onclickCreate(View view) {
        Intent myIntent = new Intent(view.getContext(),CreateNewAccount.class);
        startActivity(myIntent);
    }
}




















