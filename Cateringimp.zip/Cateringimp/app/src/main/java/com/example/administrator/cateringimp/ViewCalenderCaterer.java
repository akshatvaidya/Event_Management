package com.example.administrator.cateringimp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

/**
 * Created by Administrator on 4/25/2018.
 */

public class ViewCalenderCaterer extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_calender_caterer);

    }
    public void onclickdummy(View view) {
        Intent myIntent=new Intent(view.getContext(),ViewSelectedEventFromCalenderCaterer.class);
        startActivity(myIntent);


    }
}
