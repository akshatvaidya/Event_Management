package com.example.administrator.cateringimp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Administrator on 4/25/2018.
 */

public class ViewSelectedEventFromCalenderCaterer extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_selected_event_fromcalender_caterer);

    }

}



