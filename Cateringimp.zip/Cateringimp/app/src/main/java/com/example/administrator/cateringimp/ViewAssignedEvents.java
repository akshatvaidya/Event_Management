package com.example.administrator.cateringimp;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ViewAssignedEvents extends AppCompatActivity {

    ArrayList<String> list;
    String event_name;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_assigned_events);

//        String name = getIntent().getStringExtra("name");
//
//        DatabaseHelper databaseHelper = new DatabaseHelper(this);
//        Cursor res = databaseHelper.getAllData("assignstaffmembers");
//        System.out.println(res.getCount());
//        if(res.getString(res.getColumnIndex(DatabaseHelper.COL_28)).equalsIgnoreCase(name)) {
//            event_name = res.getString(res.getColumnIndex(DatabaseHelper.COL_15));
//        }
//
//
//        DatabaseHelper databaseHelper1 = new DatabaseHelper(this);
//        Cursor res1 = databaseHelper.getAllData("addresources");
//
//        list = new ArrayList<String>();
//        int i = 0;
//
//        res1.moveToFirst();
//        do {
//            String s = res1.getString(res1.getColumnIndex(DatabaseHelper.COL_15));
////            System.out.println("Comparing 1 " + s);
////            System.out.println(id);
////            String ss = res.getString(0);
////           System.out.println("Comparing 0 " + ss);
//            if (s != null)
//                if (s.equalsIgnoreCase(event_name)) {
//                    list.add(event_name);
//                }
//        } while (res1.moveToNext());
//
//        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
//        ListView listView = findViewById(R.id.assignedeventlist);
//        listView.setAdapter(adapter);
//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long id) {
//                startActivity(new Intent(ViewAssignedEvents.this, ViewSelectedEventFromListCatererStaff.class)
//                        .putExtra("eventName", list.get(i).split("\t\t")[1]));
//            }
//        });

    }

    public void onclickDOne(View view) {
        Intent myIntent = new Intent(view.getContext(), CatererStaffHomeScreen.class);
        startActivity(myIntent);
    }

    public void onclickempty(View view) {
        Intent myIntent = new Intent(view.getContext(), ViewSelectedEvent.class);
        startActivity(myIntent);

    }

    public void dummy(View view) {
        Intent myIntent = new Intent(view.getContext(), SearchSystemUser.class);
        startActivity(myIntent);

    }
}
