package com.example.administrator.cateringimp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class CatererHomeScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_caterer_home_screen);

        findViewById(R.id.button36).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CatererHomeScreen.this, CalenderActivity.class));
            }
        });

    }

    public void onclickLogout(View view) {
        Intent myIntent = new Intent(view.getContext(), Login.class);
        startActivity(myIntent);
    }

    public void onclickupdate(View view) {
        Intent myIntent = new Intent(view.getContext(), UpdateProfile.class);
        startActivity(myIntent);
    }

    public void onclickcreate(View view) {
        Intent myIntent = new Intent(view.getContext(), CreateNewEvent.class);
        startActivity(myIntent);
    }

    public void onClickViewEventRequests(View view) {
        Intent myIntent = new Intent(view.getContext(), ViewEventRequests.class);
        startActivity(myIntent);
    }

    public void onClickSeachForEvent(View view) {
        Intent myIntent = new Intent(view.getContext(), SearchEvent.class);
        startActivity(myIntent);
    }
}
