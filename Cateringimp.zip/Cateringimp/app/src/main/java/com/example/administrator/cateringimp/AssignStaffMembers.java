package com.example.administrator.cateringimp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.CheckBox;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AssignStaffMembers extends AppCompatActivity {

    SQLiteOpenHelper openHelper;
    SQLiteDatabase db;
    CheckBox Ak,Pa,Ki,Ha,An,Ra,Su,Rac;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assign_staff_members);
        openHelper = new DatabaseHelper(this);
        db = openHelper.getWritableDatabase();

        Ak = (CheckBox) findViewById(R.id.checkAkshat);
        Pa = (CheckBox) findViewById(R.id.checkPavithra);
        Su = (CheckBox) findViewById(R.id.checkSurya);
        Ki= (CheckBox) findViewById(R.id.checkKishore);
        Ha = (CheckBox) findViewById(R.id.checkHarini);
        An = (CheckBox) findViewById(R.id.checkAnna);
        Rac= (CheckBox) findViewById(R.id.checkRachna);
        Ra = (CheckBox) findViewById(R.id.checkRadha);
    }


    public void onclickResource(View view) {
        Intent myIntent=new Intent(view.getContext(),AddResources.class);
        String event_name = getIntent().getStringExtra("extra");
       // Log.e("cateringimp","ASM The event name is" + event_name);
        String name;
        ContentValues contentValues = new ContentValues();

        Log.e("cateringimp","ASM it is checked " + Ak.isChecked());

        if(Ak.isChecked())
        {

         name = "Akshat";
            Log.d("cateringimp","Does it come here ?" );
         contentValues.put(DatabaseHelper.COL_28,name);
            contentValues.put(DatabaseHelper.COL_15,event_name);
            //contentValues1.put(DatabaseHelper.COL_22,date);
            //contentValues.put(DatabaseHelper.COL_22,"11/11/18");

            long id1 = db.insert("assignstaffmembers", null,contentValues);
        }
        if(Rac.isChecked())
        {
            name = "Rachana";
            Log.d("cateringimp","Does it come here ?" );
            contentValues.put(DatabaseHelper.COL_28,name);
            contentValues.put(DatabaseHelper.COL_15,event_name);
            //contentValues1.put(DatabaseHelper.COL_22,date);
            //contentValues.put(DatabaseHelper.COL_22,"11/11/18");

            long id1 = db.insert("assignstaffmembers", null,contentValues);
        }
        if(Ra.isChecked())
        {
            name = "Radha";
            Log.d("cateringimp","Does it come here ?" );
            contentValues.put(DatabaseHelper.COL_28,name);
            contentValues.put(DatabaseHelper.COL_15,event_name);
            //contentValues1.put(DatabaseHelper.COL_22,date);
            //contentValues.put(DatabaseHelper.COL_22,"11/11/18");

            long id1 = db.insert("assignstaffmembers", null,contentValues);
        }
        if(Ki.isChecked())
        {
            name = "Kishore";
            Log.d("cateringimp","Does it come here ?" );
            contentValues.put(DatabaseHelper.COL_28,name);
            contentValues.put(DatabaseHelper.COL_15,event_name);
            //contentValues1.put(DatabaseHelper.COL_22,date);
            //contentValues.put(DatabaseHelper.COL_22,"11/11/18");

            long id1 = db.insert("assignstaffmembers", null,contentValues);
        }
        if(Su.isChecked())
        {
            name = "Surya";
            Log.d("cateringimp","Does it come here ?" );
            contentValues.put(DatabaseHelper.COL_28,name);
            contentValues.put(DatabaseHelper.COL_15,event_name);
            //contentValues1.put(DatabaseHelper.COL_22,date);
            //contentValues.put(DatabaseHelper.COL_22,"11/11/18");

            long id1 = db.insert("assignstaffmembers", null,contentValues);
        }
        if(An.isChecked())
        {
            name = "Anna";
            Log.d("cateringimp","Does it come here ?" );
            contentValues.put(DatabaseHelper.COL_28,name);
            contentValues.put(DatabaseHelper.COL_15,event_name);
            //contentValues1.put(DatabaseHelper.COL_22,date);
            //contentValues.put(DatabaseHelper.COL_22,"11/11/18");

            long id1 = db.insert("assignstaffmembers", null,contentValues);
        }
        if(Pa.isChecked())
        {
            name = "Pavithra";
            Log.d("cateringimp","Does it come here ?" );
            contentValues.put(DatabaseHelper.COL_28,name);
            contentValues.put(DatabaseHelper.COL_15,event_name);
            //contentValues1.put(DatabaseHelper.COL_22,date);
            //contentValues.put(DatabaseHelper.COL_22,"11/11/18");

            long id1 = db.insert("assignstaffmembers", null,contentValues);
        }
        if(Ha.isChecked())
        {
            name = "Harini";
            Log.d("cateringimp","Does it come here ?" );
            contentValues.put(DatabaseHelper.COL_28,name);
            contentValues.put(DatabaseHelper.COL_15,event_name);
            //contentValues1.put(DatabaseHelper.COL_22,date);
            //contentValues.put(DatabaseHelper.COL_22,"11/11/18");

            long id1 = db.insert("assignstaffmembers", null,contentValues);

        }


        myIntent.putExtra("extra", event_name);

        Toast.makeText(this, "Staff Members Assigned Sucessfully", Toast.LENGTH_SHORT).show();
        startActivity(myIntent);
    }

}
