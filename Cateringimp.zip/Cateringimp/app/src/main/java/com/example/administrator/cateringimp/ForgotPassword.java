package com.example.administrator.cateringimp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class ForgotPassword extends AppCompatActivity {
    EditText _txtemail;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);
        _txtemail = (EditText) findViewById(R.id.txtemail);
    }

    public void onclickSubmit(View view) {
        //Intent myIntent=new Intent(
        // view.getContext(),Login.class);
        //startActivity(myIntent);
        String email = _txtemail.getText().toString();
        Intent i = new Intent(Intent.ACTION_SEND);
        i.setType("message/rfc822");
        i.putExtra(Intent.EXTRA_EMAIL  , new String[]{email});
        i.putExtra(Intent.EXTRA_SUBJECT, "Reset your password");
        i.putExtra(Intent.EXTRA_TEXT   , "your new password is jimmy");
        try {
            startActivity(Intent.createChooser(i, "Send mail..."));
        } catch (android.content.ActivityNotFoundException ex) {
            Toast.makeText(this, "There are no email clients installed.", Toast.LENGTH_SHORT).show();
        }
        Intent myIntent = new Intent(view.getContext(), Login.class);
        finish();
        startActivity(myIntent);

        Toast.makeText(this, "Your password has been emailed to you", Toast.LENGTH_SHORT).show();
    }
}
