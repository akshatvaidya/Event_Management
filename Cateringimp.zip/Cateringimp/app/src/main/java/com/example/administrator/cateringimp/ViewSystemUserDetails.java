package com.example.administrator.cateringimp;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ViewSystemUserDetails extends AppCompatActivity {
    SQLiteOpenHelper openHelper;
    SQLiteDatabase sqLiteDatabase;

    TextView tv1,tv2,tv3,tv4,tv5,tv6,tv7,tv8,tv9,tv10;
    String fn,ln;
    Cursor res;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_system_user_details);

        DatabaseHelper helper = new DatabaseHelper(this);

        res = helper.getAllData("register");

        fn = getIntent().getStringExtra("name");
        ln = getIntent().getStringExtra("surname");

        tv1 = findViewById(R.id.textView67);
        tv2 = findViewById(R.id.textView45);
        tv3 = findViewById(R.id.textView44);
        tv4 = findViewById(R.id.textView46);
        tv5 = findViewById(R.id.textView58);
        tv6 = findViewById(R.id.textView66);
        tv7 = findViewById(R.id.textView71);
        tv8 = findViewById(R.id.textView73);
        tv9 = findViewById(R.id.textView70);
        tv10 = findViewById(R.id.textView72);
        //TextView textView = findViewById(R.id.textView67);
        System.out.println(fn);
        System.out.println(res.getCount());
        res.moveToFirst();
        do {
            if (res.getString(res.getColumnIndex(DatabaseHelper.COL_3)).equalsIgnoreCase(fn) &&
                    res.getString(res.getColumnIndex(DatabaseHelper.COL_4)).equalsIgnoreCase(ln)) {
                tv1.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_3)) + "\t" +
                        res.getString(res.getColumnIndex(DatabaseHelper.COL_4)));
                tv2.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_1)));
                tv3.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_5)));
                tv4.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_12)));
                tv5.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_6)));
                tv6.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_7)));
                tv7.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_9)));
                tv8.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_13)));
                tv9.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_11)));
                tv10.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_14)));


            }
        }
        while (res.moveToNext());


    }

    public void onclickdummy3(View view) {
        Intent myIntent = new Intent(view.getContext(), CreateNewEvent.class);
        startActivity(myIntent);
    }

    public void onclickabc(View view) {
        Intent myIntent = new Intent(view.getContext(), AdminHomeScreen.class);
        startActivity(myIntent);
        Toast.makeText(getApplicationContext(), "Successfully Deleted", Toast.LENGTH_SHORT).show();
        //sqLiteDatabase=openHelper.getWritableDatabase();
       // sqLiteDatabase.delete(DatabaseHelper.TABLE_NAME,"NAME= ? ", new String[]{fn});

        /*

        sqLiteDatabase = openHelper.getWritableDatabase();
        String id = _txtid.getText().toString();
        ContentValues contentValues = new ContentValues();
        contentValues.put(DatabaseHelper.COL_1, id);
        sqLiteDatabase.delete(DatabaseHelper.TABLE_NAME,"UTAID= ? ", new String[]{id});
        Intent myIntent=new Intent(view.getContext(),CatererStaffHomeScreen.class);
        Toast.makeText(this, "Profile deleted Sucessfully", Toast.LENGTH_SHORT).show();
        startActivity(myIntent);
         */



    }
}
