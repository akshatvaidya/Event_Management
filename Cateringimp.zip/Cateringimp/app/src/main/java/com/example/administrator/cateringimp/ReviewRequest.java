package com.example.administrator.cateringimp;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class ReviewRequest extends AppCompatActivity {

    String name, uid;
    TextView tv1, tv2, tv3, tv4, tv5, tv6, tv7, tv8, tv9, tv10, tv11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_request);

        name = getIntent().getStringExtra("name");
        uid = getIntent().getStringExtra("uid");


        tv1 = findViewById(R.id.textView11);
        tv2 = findViewById(R.id.textView5);
        tv3 = findViewById(R.id.textView12);
        tv4 = findViewById(R.id.textView6);
        tv5 = findViewById(R.id.textView3);
        tv6 = findViewById(R.id.textView8);
        tv7 = findViewById(R.id.textView10);
        tv8 = findViewById(R.id.textView9);
        tv9 = findViewById(R.id.textView15);
        tv10 = findViewById(R.id.textView14);
        tv11 = findViewById(R.id.textView16);



        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        Cursor res;
        res = databaseHelper.getAllData("register");
        System.out.println(res.getCount());
        res.moveToFirst();
        do {
            System.out.println("name:"+res.getString(res.getColumnIndex(DatabaseHelper.COL_3)));
            System.out.println("id"+res.getString(res.getColumnIndex(DatabaseHelper.COL_1)));
            System.out.println("name"+name);
            System.out.println("id"+uid);
            System.out.println(res.getString(res.getColumnIndex(DatabaseHelper.COL_11)));

            if (res.getString(res.getColumnIndex(DatabaseHelper.COL_3)).equalsIgnoreCase(name) &&
                    res.getString(res.getColumnIndex(DatabaseHelper.COL_1)).equalsIgnoreCase(uid)) {
                tv1.setText(name);
                tv2.setText(uid);
                tv3.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_4)));
                tv4.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_12)));
                tv5.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_5)));
                tv6.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_6)));
                tv7.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_7)));
                tv8.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_8)));
                tv9.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_9)));
                tv10.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_11)));
                tv11.setText(res.getString(res.getColumnIndex(DatabaseHelper.COL_14)));
                break;
            }
        }
        while (res.moveToNext());


    }

    public void onclickAccept(View view) {
        Intent myIntent = new Intent(view.getContext(), ReviewRegisterationRequestList.class);
        startActivity(myIntent);
        Toast.makeText(this, "New User Added", Toast.LENGTH_SHORT).show();
    }

    public void onCLickReject(View view) {
        Intent myIntent = new Intent(view.getContext(), ReviewRegisterationRequestList.class);
        startActivity(myIntent);
        Toast.makeText(this, "User Rejected", Toast.LENGTH_SHORT).show();
    }
}

