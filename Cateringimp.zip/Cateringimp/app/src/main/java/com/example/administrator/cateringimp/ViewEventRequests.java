package com.example.administrator.cateringimp;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class ViewEventRequests extends AppCompatActivity {

    ArrayList<String> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_event_requests);

        //String id = getIntent().getStringExtra("userid");

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        Cursor res = databaseHelper.getAllData("bookevent");
        System.out.println(res.getCount());
        list = new ArrayList<String>();
        int i = 0;

        res.moveToFirst();
        do {
            //String s = res.getString(res.getColumnIndex(DatabaseHelper.COL_1));
           // System.out.println("Comparing 1 " + s);
            //System.out.println(id);
//            String ss = res.getString(0);
//           System.out.println("Comparing 0 " + ss);
                    list.add(i, res.getString(res.getColumnIndex(DatabaseHelper.COL_22)) + "\t\t" +
                            res.getString(res.getColumnIndex(DatabaseHelper.COL_15)));

        } while (res.moveToNext());

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        ListView listView = findViewById(R.id.eventrequestlist);
        listView.setAdapter(adapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long id) {
                startActivity(new Intent(ViewEventRequests.this, ViewSelectedEventFromListCaterer.class)
                        .putExtra("eventName", list.get(i).split("\t\t")[1]));
            }
        });
    }
}
